export type UserRole = "student" | "admin";

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  profileImage?: string;
  createdAt: string;
  updatedAt?: string;
}
