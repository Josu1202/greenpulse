"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { Camera, Trash2, UserCircle } from "lucide-react";

import { MainLayout, ProtectedRoute } from "@/components/layout";
import {
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  Input,
} from "@/components/ui";
import { useAuth } from "@/hooks/useAuth";
import {
  changePasswordSchema,
  profileSchema,
  type ChangePasswordFormData,
  type ProfileFormData,
} from "@/schemas";
import { fileToDataUrl } from "@/utils/image";

function getInitials(name: string): string {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part.charAt(0))
    .join("")
    .toUpperCase();
}

type ProfileErrors = Partial<Record<keyof ProfileFormData, string>>;
type PasswordErrors = Partial<Record<keyof ChangePasswordFormData, string>>;

function ProfileContent() {
  const router = useRouter();
  const {
    user,
    error,
    updateCurrentUser,
    changeCurrentUserPassword,
    deleteCurrentUser,
  } = useAuth();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [profileImage, setProfileImage] = useState<string | undefined>();

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [profileErrors, setProfileErrors] = useState<ProfileErrors>({});
  const [passwordErrors, setPasswordErrors] = useState<PasswordErrors>({});
  const [imageError, setImageError] = useState<string | null>(null);
  const [profileSuccess, setProfileSuccess] = useState<string | null>(null);
  const [passwordSuccess, setPasswordSuccess] = useState<string | null>(null);
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [isSavingPassword, setIsSavingPassword] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (!user) return;

    setName(user.name);
    setEmail(user.email);
    setProfileImage(user.profileImage);
  }, [user]);

  if (!user) {
    return null;
  }

  const initials = getInitials(user.name) || "GP";

  const handleImageChange = async (
    event: ChangeEvent<HTMLInputElement>
  ): Promise<void> => {
    const file = event.target.files?.[0];

    if (!file) {
      setImageError(null);
      return;
    }

    try {
      setImageError(null);
      const dataUrl = await fileToDataUrl(file);
      setProfileImage(dataUrl);
    } catch (error) {
      setImageError(
        error instanceof Error ? error.message : "No se pudo cargar la imagen."
      );
    }
  };

  const handleProfileSubmit = async (event: FormEvent) => {
    event.preventDefault();

    const result = profileSchema.safeParse({
      name,
      email,
      profileImage,
    });

    if (!result.success) {
      const flat = result.error.flatten().fieldErrors;

      setProfileErrors({
        name: flat.name?.[0],
        email: flat.email?.[0],
        profileImage: flat.profileImage?.[0],
      });
      return;
    }

    try {
      setIsSavingProfile(true);
      setProfileErrors({});
      setProfileSuccess(null);

      await updateCurrentUser(result.data);
      setProfileSuccess("Tus datos fueron actualizados correctamente.");
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handlePasswordSubmit = async (event: FormEvent) => {
    event.preventDefault();

    const result = changePasswordSchema.safeParse({
      currentPassword,
      newPassword,
      confirmPassword,
    });

    if (!result.success) {
      const flat = result.error.flatten().fieldErrors;

      setPasswordErrors({
        currentPassword: flat.currentPassword?.[0],
        newPassword: flat.newPassword?.[0],
        confirmPassword: flat.confirmPassword?.[0],
      });
      return;
    }

    try {
      setIsSavingPassword(true);
      setPasswordErrors({});
      setPasswordSuccess(null);

      await changeCurrentUserPassword(
        result.data.currentPassword,
        result.data.newPassword
      );

      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setPasswordSuccess("Tu contraseña fue actualizada correctamente.");
    } finally {
      setIsSavingPassword(false);
    }
  };

  const handleDeleteAccount = async () => {
    const confirmed = window.confirm(
      "¿Eliminar tu usuario? También se eliminarán tus reportes locales. Esta acción no se puede deshacer."
    );

    if (!confirmed) return;

    try {
      setIsDeleting(true);
      await deleteCurrentUser();
      router.replace("/");
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <MainLayout>
      <div className="mx-auto max-w-4xl space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-950">Mi perfil</h1>
          <p className="text-slate-600">
            Actualiza tus datos de usuario, foto de perfil y contraseña.
          </p>
        </div>

        {error ? (
          <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">
            {error}
          </p>
        ) : null}

        <div className="grid gap-6 lg:grid-cols-[1fr_0.8fr]">
          <Card>
            <CardHeader>
              <CardTitle>Datos personales</CardTitle>
              <CardDescription>
                Estos datos se guardan localmente en IndexedDB.
              </CardDescription>
            </CardHeader>

            <CardContent>
              <form onSubmit={handleProfileSubmit} className="space-y-4">
                <div className="flex flex-col items-center gap-3 sm:flex-row sm:items-center">
                  <div className="relative flex h-24 w-24 items-center justify-center overflow-hidden rounded-full border border-slate-200 bg-slate-50">
                    {profileImage ? (
                      <Image
                        src={profileImage}
                        alt={`Foto de perfil de ${user.name}`}
                        fill
                        unoptimized
                        className="object-cover"
                      />
                    ) : (
                      <span className="flex h-full w-full items-center justify-center bg-green-100 text-xl font-semibold text-green-700">
                        {initials || <UserCircle className="h-10 w-10" />}
                      </span>
                    )}
                  </div>

                  <div className="w-full space-y-1.5">
                    <label
                      htmlFor="profileImage"
                      className="flex items-center gap-2 text-sm font-medium text-slate-700"
                    >
                      <Camera className="h-4 w-4" />
                      Foto de perfil
                    </label>
                    <input
                      id="profileImage"
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={handleImageChange}
                      className="block w-full text-sm text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-green-50 file:px-3 file:py-2 file:text-sm file:font-medium file:text-green-700 hover:file:bg-green-100"
                    />
                    {imageError || profileErrors.profileImage ? (
                      <p className="text-sm text-red-600">
                        {imageError ?? profileErrors.profileImage}
                      </p>
                    ) : (
                      <p className="text-xs text-slate-500">
                        Formatos permitidos: JPG, PNG o WEBP. Máximo 2 MB.
                      </p>
                    )}
                  </div>
                </div>

                <Input
                  label="Nombre completo"
                  name="name"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  error={profileErrors.name}
                  autoComplete="name"
                />

                <Input
                  label="Correo electrónico"
                  type="email"
                  name="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  error={profileErrors.email}
                  autoComplete="email"
                />

                {profileSuccess ? (
                  <p className="rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700">
                    {profileSuccess}
                  </p>
                ) : null}

                <Button type="submit" disabled={isSavingProfile}>
                  {isSavingProfile ? "Guardando..." : "Guardar cambios"}
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Cambiar contraseña</CardTitle>
                <CardDescription>
                  Debes ingresar tu contraseña actual para cambiarla.
                </CardDescription>
              </CardHeader>

              <CardContent>
                <form onSubmit={handlePasswordSubmit} className="space-y-4">
                  <Input
                    label="Contraseña actual"
                    type="password"
                    name="currentPassword"
                    value={currentPassword}
                    onChange={(event) => setCurrentPassword(event.target.value)}
                    error={passwordErrors.currentPassword}
                    autoComplete="current-password"
                  />

                  <Input
                    label="Nueva contraseña"
                    type="password"
                    name="newPassword"
                    value={newPassword}
                    onChange={(event) => setNewPassword(event.target.value)}
                    error={passwordErrors.newPassword}
                    autoComplete="new-password"
                  />

                  <Input
                    label="Confirmar contraseña"
                    type="password"
                    name="confirmPassword"
                    value={confirmPassword}
                    onChange={(event) => setConfirmPassword(event.target.value)}
                    error={passwordErrors.confirmPassword}
                    autoComplete="new-password"
                  />

                  {passwordSuccess ? (
                    <p className="rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700">
                      {passwordSuccess}
                    </p>
                  ) : null}

                  <Button type="submit" disabled={isSavingPassword}>
                    {isSavingPassword ? "Actualizando..." : "Cambiar contraseña"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card className="border-red-100">
              <CardHeader>
                <CardTitle className="text-red-700">Zona de riesgo</CardTitle>
                <CardDescription>
                  Eliminar tu usuario también eliminará tus reportes locales.
                </CardDescription>
              </CardHeader>

              <CardContent>
                <Button
                  type="button"
                  variant="danger"
                  onClick={handleDeleteAccount}
                  disabled={isDeleting}
                  className="gap-2"
                >
                  <Trash2 className="h-4 w-4" />
                  {isDeleting ? "Eliminando..." : "Eliminar mi usuario"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}

export default function ProfilePage() {
  return (
    <ProtectedRoute>
      <ProfileContent />
    </ProtectedRoute>
  );
}
