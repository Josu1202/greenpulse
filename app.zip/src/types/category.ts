export interface Category {
  id: string;
  name: string;
  color: string;
  description: string;
  impactFactor: number;
}