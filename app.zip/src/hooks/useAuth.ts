"use client";

import { useCallback, useEffect, useState } from "react";

import {
  changeUserPassword,
  createUser,
  deleteUser,
  getUserById,
  updateUser,
  updateUserProfileImage,
  resetUserPasswordByEmail,
  validateUserLogin,
  type CreateUserInput,
  type UpdateUserInput,
} from "@/db/repositories";
import type { User } from "@/types";
import {
  clearSessionUserId,
  getSessionUserId,
  saveSessionUserId,
} from "@/utils/session";

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadSession = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      const userId = getSessionUserId();

      if (!userId) {
        setUser(null);
        return;
      }

      const storedUser = await getUserById(userId);

      if (!storedUser) {
        clearSessionUserId();
        setUser(null);
        return;
      }

      setUser(storedUser);
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "No se pudo cargar la sesión.";

      setError(message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const register = async (input: CreateUserInput): Promise<User> => {
    try {
      setError(null);

      const createdUser = await createUser(input);

      saveSessionUserId(createdUser.id);
      setUser(createdUser);

      return createdUser;
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "No se pudo registrar el usuario.";

      setError(message);
      throw error;
    }
  };

  const login = async (email: string, password: string): Promise<User> => {
    try {
      setError(null);

      const validUser = await validateUserLogin(email, password);

      if (!validUser) {
        throw new Error("Correo o contraseña incorrectos.");
      }

      saveSessionUserId(validUser.id);
      setUser(validUser);

      return validUser;
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "No se pudo iniciar sesión.";

      setError(message);
      throw error;
    }
  };

  const logout = (): void => {
    clearSessionUserId();
    setUser(null);
  };

  const refreshUser = async (): Promise<User | null> => {
    const userId = getSessionUserId();

    if (!userId) {
      setUser(null);
      return null;
    }

    const storedUser = await getUserById(userId);

    if (!storedUser) {
      clearSessionUserId();
      setUser(null);
      return null;
    }

    setUser(storedUser);
    return storedUser;
  };

  const updateCurrentUser = async (
    input: UpdateUserInput
  ): Promise<User> => {
    if (!user) {
      throw new Error("No hay una sesión activa.");
    }

    try {
      setError(null);

      const updatedUser = await updateUser(user.id, input);
      setUser(updatedUser);

      return updatedUser;
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "No se pudo actualizar el usuario.";

      setError(message);
      throw error;
    }
  };

  const updateCurrentUserProfileImage = async (
    profileImage: string
  ): Promise<User> => {
    if (!user) {
      throw new Error("No hay una sesión activa.");
    }

    try {
      setError(null);

      const updatedUser = await updateUserProfileImage(user.id, profileImage);
      setUser(updatedUser);

      return updatedUser;
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "No se pudo actualizar la foto de perfil.";

      setError(message);
      throw error;
    }
  };

  const changeCurrentUserPassword = async (
    currentPassword: string,
    newPassword: string
  ): Promise<User> => {
    if (!user) {
      throw new Error("No hay una sesión activa.");
    }

    try {
      setError(null);

      const updatedUser = await changeUserPassword(
        user.id,
        currentPassword,
        newPassword
      );

      setUser(updatedUser);

      return updatedUser;
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "No se pudo cambiar la contraseña.";

      setError(message);
      throw error;
    }
  };

  const deleteCurrentUser = async (): Promise<void> => {
    if (!user) {
      throw new Error("No hay una sesión activa.");
    }

    try {
      setError(null);

      await deleteUser(user.id);
      clearSessionUserId();
      setUser(null);
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "No se pudo eliminar el usuario.";

      setError(message);
      throw error;
    }
  };

  const resetPasswordByEmail = async (
    email: string,
    newPassword: string
  ): Promise<User> => {
    try {
      setError(null);

      const updatedUser = await resetUserPasswordByEmail(email, newPassword);

      return updatedUser;
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "No se pudo restablecer la contraseña.";

      setError(message);
      throw error;
    }
  };

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadSession();
    }, 0);

    return () => {
      window.clearTimeout(timer);
    };
  }, [loadSession]);

  return {
    user,
    isAuthenticated: Boolean(user),
    isLoading,
    error,
    register,
    login,
    logout,
    loadSession,
    refreshUser,
    updateCurrentUser,
    updateCurrentUserProfileImage,
    changeCurrentUserPassword,
    deleteCurrentUser,
    resetPasswordByEmail,
  };
}