import { db } from "@/db/database";
import type { User, UserRole } from "@/types";

export interface CreateUserInput {
  name: string;
  email: string;
  password: string;
  role?: UserRole;
  profileImage?: string;
}

export interface UpdateUserInput {
  name?: string;
  email?: string;
  password?: string;
  role?: UserRole;
  profileImage?: string;
}

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

function normalizeName(name: string): string {
  return name.trim();
}

export async function getAllUsers(): Promise<User[]> {
  return db.users.orderBy("createdAt").reverse().toArray();
}

export async function getUserById(id: string): Promise<User | undefined> {
  return db.users.get(id);
}

export async function getUserByEmail(email: string): Promise<User | undefined> {
  return db.users.where("email").equals(normalizeEmail(email)).first();
}

export async function createUser(input: CreateUserInput): Promise<User> {
  const name = normalizeName(input.name);
  const email = normalizeEmail(input.email);
  const password = input.password.trim();

  if (!name) {
    throw new Error("El nombre es obligatorio.");
  }

  if (!email) {
    throw new Error("El correo es obligatorio.");
  }

  if (!password) {
    throw new Error("La contraseña es obligatoria.");
  }

  const existingUser = await getUserByEmail(email);

  if (existingUser) {
    throw new Error("Ya existe un usuario registrado con este correo.");
  }

  const user: User = {
    id: crypto.randomUUID(),
    name,
    email,
    password,
    role: input.role ?? "student",
    profileImage: input.profileImage,
    createdAt: new Date().toISOString(),
  };

  await db.users.add(user);

  return user;
}

export async function updateUser(
  id: string,
  input: UpdateUserInput
): Promise<User> {
  const existingUser = await getUserById(id);

  if (!existingUser) {
    throw new Error("El usuario no existe.");
  }

  const changes: Partial<User> = {};

  if (input.name !== undefined) {
    const name = normalizeName(input.name);

    if (!name) {
      throw new Error("El nombre no puede quedar vacío.");
    }

    changes.name = name;
  }

  if (input.email !== undefined) {
    const email = normalizeEmail(input.email);

    if (!email) {
      throw new Error("El correo no puede quedar vacío.");
    }

    const userWithSameEmail = await getUserByEmail(email);

    if (userWithSameEmail && userWithSameEmail.id !== id) {
      throw new Error("Ya existe otro usuario registrado con este correo.");
    }

    changes.email = email;
  }

  if (input.password !== undefined) {
    const password = input.password.trim();

    if (!password) {
      throw new Error("La contraseña no puede quedar vacía.");
    }

    changes.password = password;
  }

  if (input.role !== undefined) {
    changes.role = input.role;
  }

  if (input.profileImage !== undefined) {
    changes.profileImage = input.profileImage;
  }

  await db.users.update(id, changes);

  return {
    ...existingUser,
    ...changes,
  };
}

export async function updateUserProfileImage(
  id: string,
  profileImage: string
): Promise<User> {
  return updateUser(id, {
    profileImage,
  });
}

export async function changeUserPassword(
  id: string,
  currentPassword: string,
  newPassword: string
): Promise<User> {
  const existingUser = await getUserById(id);

  if (!existingUser) {
    throw new Error("El usuario no existe.");
  }

  if (existingUser.password !== currentPassword) {
    throw new Error("La contraseña actual es incorrecta.");
  }

  return updateUser(id, {
    password: newPassword,
  });
}

export async function validateUserLogin(
  email: string,
  password: string
): Promise<User | null> {
  const user = await getUserByEmail(email);

  if (!user) {
    return null;
  }

  if (user.password !== password) {
    return null;
  }

  return user;
}

export async function deleteUser(id: string): Promise<void> {
  const existingUser = await getUserById(id);

  if (!existingUser) {
    throw new Error("El usuario no existe.");
  }

  await db.users.delete(id);
}

export async function clearUsers(): Promise<void> {
  await db.users.clear();
}

export async function resetUserPasswordByEmail(
  email: string,
  newPassword: string
): Promise<User> {
  const normalizedEmail = normalizeEmail(email);
  const user = await getUserByEmail(normalizedEmail);

  if (!user) {
    throw new Error("No existe un usuario registrado con este correo.");
  }

  const password = newPassword.trim();

  if (!password) {
    throw new Error("La nueva contraseña no puede quedar vacía.");
  }

  await db.users.update(user.id, {
    password,
  });

  return {
    ...user,
    password,
  };
}