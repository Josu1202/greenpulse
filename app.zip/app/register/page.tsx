"use client";

import { useRouter } from "next/navigation";

import { AuthLayout } from "@/components/layout";
import { RegisterForm } from "@/features/auth";
import type { RegisterFormData } from "@/schemas";
import { useAuth } from "@/hooks/useAuth";

export default function RegisterPage() {
  const router = useRouter();
  const { register, error } = useAuth();

  const handleRegister = async (values: RegisterFormData) => {
    await register(values);
    router.push("/dashboard");
  };

  return (
    <AuthLayout>
      <RegisterForm onSubmit={handleRegister} error={error} />
    </AuthLayout>
  );
}