"use client";

import { useRouter } from "next/navigation";

import { AuthLayout } from "@/components/layout";
import { LoginForm } from "@/features/auth";
import type { LoginFormData } from "@/schemas";
import { useAuth } from "@/hooks/useAuth";

export default function LoginPage() {
  const router = useRouter();
  const { login, error } = useAuth();

  const handleLogin = async (values: LoginFormData) => {
    await login(values.email, values.password);
    router.push("/dashboard");
  };

  return (
    <AuthLayout>
      <LoginForm onSubmit={handleLogin} error={error} />
    </AuthLayout>
  );
}